package Cells;

import Upgrades.Upgrade;


public class Cell {
    private final boolean isMovable;
    private final Upgrade upgrade;
    private final CellType cellType;
    private int row;
    private int column;


    /* empty = new Cell(, , true, null, CellType.EMPTY);
     point = new Cell(, , true, null, CellType.POINT);
     upgrade = new Cell(, , true, new Upgrade(), CellType.UPGRADE);
     wall = new Cell(, , false, null, CellType.WALL);*/
    public Cell(int row, int column, boolean isMovable, Upgrade upgrade, CellType cellType) {
        this.row = row;
        this.column = column;
        this.isMovable = isMovable;
        this.upgrade = upgrade;
        this.cellType = cellType;
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }

    public boolean isMovable() {
        return isMovable;
    }

    public Upgrade getUpgrade() {
        return upgrade;
    }

    public CellType getCellType() {
        return cellType;
    }

}
