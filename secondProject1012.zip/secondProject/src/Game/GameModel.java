package Game;

import Cells.Cell;
import Characters.GameCharacter;
import Characters.Ghost;
import Characters.GhostColor;
import Characters.Pacman;
import Upgrades.Upgrade;

import java.util.ArrayList;
import java.util.List;

public class GameModel {


    private final ArrayList<GameCharacter> playerList = new ArrayList<>();
    public GameTableModel gameBoard;
    private List<Upgrade> upgradeList;
    private boolean isGameActive;
    private int currentScore;
    private int currentHealth;

    public GameModel() {
        initializeGame();
    }


    public void initializeGame() {
        GameField gameField = new GameField();
        currentScore = 0;
        currentHealth = 3;
        upgradeList = new ArrayList<>();
        gameBoard = new GameTableModel(gameField.returnMaze18());
        resetCharacters();
        isGameActive = false;
    }

    public List<GameCharacter> getPlayerList() {
        return playerList;
    }

    public Pacman getPacman() {
        return playerList.stream()
                .filter(player -> player instanceof Pacman)
                .map(player -> (Pacman) player)
                .findFirst()
                .orElse(null);
    }

    public Cell[][] getGameBoard() {
        return gameBoard.getCells();
    }


    public boolean getIfGhostTouchedPacman() {
        Pacman pacman = getPacman();

        if (pacman != null) {
            int row = pacman.getRow();
            int column = pacman.getColumn();

            for (GameCharacter character : playerList) {
                if (!(character instanceof Pacman) && character.getColumn() == column && character.getRow() == row)
                    return true;
            }
        }
        return false;

    }


    public boolean isGameActive() {
        return isGameActive;
    }

    public void setGameActive(boolean gameActive) {
        this.isGameActive = gameActive;
    }

    public int getCurrentScore() {
        return currentScore;
    }

    public void setCurrentScore(int currentScore) {
        this.currentScore = currentScore;
    }

    public int getCurrentHealth() {
        return currentHealth;
    }

    public void setCurrentHealth(int currentHealth) {
        this.currentHealth = currentHealth;
    }

    public void resetCharacters() {
        playerList.clear();
        upgradeList.clear();
        playerList.add(new Pacman(1, 1, 300));
        playerList.add(new Ghost(8, 9, 300, GhostColor.BLUE));
        playerList.add(new Ghost(8, 9, 300, GhostColor.RED));
        playerList.add(new Ghost(8, 9, 300, GhostColor.PINK));
        playerList.add(new Ghost(8, 9, 300, GhostColor.ORANGE));


    }

    public List<Upgrade> getUpgradeList() {
        return upgradeList;
    }


}