package Cells;

public enum CellType {
    EMPTY,
    POINT,
    UPGRADE,
    WALL
}
