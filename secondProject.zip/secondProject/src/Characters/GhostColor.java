package Characters;

public enum GhostColor {
    RED, PINK, ORANGE, BLUE
}
