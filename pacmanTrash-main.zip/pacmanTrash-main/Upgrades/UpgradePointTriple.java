package Upgrades;

import Game.GameModel;
import Upgrades.Upgrade;

public class UpgradePointTriple extends Upgrade {
    public UpgradePointTriple(){
        duration = 2500;
        image = "src/resources/grapeFruit.png";
    }
    @Override
    public void start(GameModel model) {

    }

    @Override
    public void reset(GameModel model) {

    }
}
