import Game.*;

public class Main {
    public static void main(String[] args) {


        ScoreModel sModel = new ScoreModel();
        ScoreView sView = new ScoreView(sModel);
        ScoreController sController = new ScoreController(sModel, sView);

        GameModel gModel = new GameModel();
        GameView gView = new GameView(gModel);
        GameController gController = new GameController(gView, gModel, sController);
        gView.setController(gController);

        MenuView mView = new MenuView(gController, sController);
        MenuController mController = new MenuController(mView);

        mController.showMenu();






        }
    }
