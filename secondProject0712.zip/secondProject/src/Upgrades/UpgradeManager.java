package Upgrades;

import Characters.Pacman;
import Game.GameModel;

public class UpgradeManager extends Upgrade {
    private UpgradeType upgradeType;

    public UpgradeManager(UpgradeType upgradeType) {
        this.upgradeType = upgradeType;
        initializeAttributes();
    }

    private void initializeAttributes() {
        switch (upgradeType) {
            case POINT_DOUBLE:
                duration = 5000;
                image = "src/resources/strawberryFruit.png";
                break;
            case POINT_TRIPLE:
                duration = 2500;
                image = "src/resources/grapeFruit.png";
                break;
            case SPEED:
                duration = 3000;
                image = "src/resources/cherry.png";
                break;
            case IMMORTALITY:
                duration = 3000;
                image = "src/resources/watermelonFruit.png";
                break;
            case ALL:
                duration = 5000;
                image = "src/resources/avocadoFruit.png";
                break;
        }
    }

    @Override
    public void start(GameModel model) {
        switch (upgradeType) {
            case SPEED:
            case ALL:
                Pacman pacman = model.getPacman();
                pacman.setSpeed(pacman.getSpeed() / 2);
                break;
        }
    }

    @Override
    public void reset(GameModel model) {
        switch (upgradeType) {
            case SPEED:
            case ALL:
                Pacman pacman = model.getPacman();
                pacman.setSpeed(pacman.getSpeed() * 2);
                break;
        }
    }
    @Override
    public UpgradeType getUpgradeType() {
        return upgradeType;
    }


}
