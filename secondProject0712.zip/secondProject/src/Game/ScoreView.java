package Game;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class ScoreView extends JFrame {
    private final ScoreModel model;
    private final JList<String> list;

    public ScoreView(ScoreModel model) {
        this.model = model;
        list = new JList<>();
        setupUI();
    }

    private void setupUI() {

        JScrollPane scrollPane = new JScrollPane(list);
        list.setLayoutOrientation(JList.VERTICAL);
        list.setBackground(Color.BLACK);
        list.setForeground(Color.ORANGE);
        list.setFont(new Font("Monospaced", Font.BOLD, 25));
        list.setCellRenderer(new CustomListCellRenderer());

        add(scrollPane, BorderLayout.CENTER);

        ImageIcon icon = new ImageIcon("src/resources/blueGhostDown.png");
        setIconImage(icon.getImage());

        setTitle("Scores");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    public JComponent getScoreComponent() {
        return list;
    }
    private static class CustomListCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            Component component = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

            if (index < list.getModel().getSize() - 1) {
                Border originalBorder = ((JComponent) component).getBorder();
                Border lineBorder = BorderFactory.createMatteBorder(0, 0, 1, 0, Color.ORANGE);
                ((JComponent) component).setBorder(BorderFactory.createCompoundBorder(originalBorder, lineBorder));
            }

            return component;
        }
    }
    public void updateScores() {
        DefaultListModel<String> modelList = new DefaultListModel<>();
        for (Score score : model.getScores()) {
            modelList.addElement(score.toString());
        }

        SwingUtilities.invokeLater(() -> list.setModel(modelList));
    }

    public void showScore() {
        setVisible(true);
    }
}

