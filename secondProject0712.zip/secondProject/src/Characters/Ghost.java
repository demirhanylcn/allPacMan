package Characters;

import Game.Animated;

public class Ghost extends GameCharacter {
    private final GhostColor color;

    public Ghost(int row, int column, int speed, GhostColor color) {
        super(row, column, speed);
        this.color = color;
        initializeAnimation();
        animated = new Animated(animation.get(inputs), 0.25);
    }

    private void initializeAnimation() {
        switch (color) {
            case RED:
                animation.put(Inputs.DOWN, new String[]{"src/resources/redGhostDown.png"});
                animation.put(Inputs.RIGHT, new String[]{"src/resources/redGhostRight.png"});
                animation.put(Inputs.LEFT, new String[]{"src/resources/redGhostLeft.png"});
                animation.put(Inputs.UP, new String[]{"src/resources/redGhostUp.png"});
                break;
            case PINK:
                animation.put(Inputs.UP, new String[]{"src/resources/pinkGhostUp.png"});
                animation.put(Inputs.DOWN, new String[]{"src/resources/pinkGhostDown.png"});
                animation.put(Inputs.RIGHT, new String[]{"src/resources/pinkGhostRight.png"});
                animation.put(Inputs.LEFT, new String[]{"src/resources/pinkGhostLeft.png"});
                break;
            case ORANGE:
                animation.put(Inputs.UP, new String[]{"src/resources/orangeGhostUp.png"});
                animation.put(Inputs.DOWN, new String[]{"src/resources/orangeGhostDown.png"});
                animation.put(Inputs.RIGHT, new String[]{"src/resources/orangeGhostRight.png"});
                animation.put(Inputs.LEFT, new String[]{"src/resources/orangeGhostLeft.png"});
                break;
            case BLUE:
                animation.put(Inputs.UP, new String[]{"src/resources/blueGhostUp.png"});
                animation.put(Inputs.DOWN, new String[]{"src/resources/blueGhostDown.png"});
                animation.put(Inputs.RIGHT, new String[]{"src/resources/blueGhostRight.png"});
                animation.put(Inputs.LEFT, new String[]{"src/resources/blueGhostLeft.png"});
                break;
        }
    }
}
