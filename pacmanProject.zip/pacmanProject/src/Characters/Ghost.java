package Characters;

import Enums.GhostColor;
import Enums.Inputs;
import Game.Animation;
import Game.Character;

public class Ghost extends Character {
    private final GhostColor color;

    public Ghost(int row, int column, int speed, GhostColor color) {
        super(row, column, speed);
        this.color = color;
        initializeAnimation();
        animated = new Animation(animation.get(inputs), 0.25);
    }

    private void initializeAnimation() {
        switch (color) {
            case RED:
                animation.put(Inputs.DOWN, new String[]{"src/Images/redGhostDown.png"});
                animation.put(Inputs.RIGHT, new String[]{"src/Images/redGhostRight.png"});
                animation.put(Inputs.LEFT, new String[]{"src/Images/redGhostLeft.png"});
                animation.put(Inputs.UP, new String[]{"src/Images/redGhostUp.png"});
                break;
            case PINK:
                animation.put(Inputs.UP, new String[]{"src/Images/pinkGhostUp.png"});
                animation.put(Inputs.DOWN, new String[]{"src/Images/pinkGhostDown.png"});
                animation.put(Inputs.RIGHT, new String[]{"src/Images/pinkGhostRight.png"});
                animation.put(Inputs.LEFT, new String[]{"src/Images/pinkGhostLeft.png"});
                break;
            case ORANGE:
                animation.put(Inputs.UP, new String[]{"src/Images/orangeGhostUp.png"});
                animation.put(Inputs.DOWN, new String[]{"src/Images/orangeGhostDown.png"});
                animation.put(Inputs.RIGHT, new String[]{"src/Images/orangeGhostRight.png"});
                animation.put(Inputs.LEFT, new String[]{"src/Images/orangeGhostLeft.png"});
                break;
            case BLUE:
                animation.put(Inputs.UP, new String[]{"src/Images/blueGhostUp.png"});
                animation.put(Inputs.DOWN, new String[]{"src/Images/blueGhostDown.png"});
                animation.put(Inputs.RIGHT, new String[]{"src/Images/blueGhostRight.png"});
                animation.put(Inputs.LEFT, new String[]{"src/Images/blueGhostLeft.png"});
                break;
        }
    }
}
