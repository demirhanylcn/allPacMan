package Characters;


import Enums.Inputs;
import Game.Animation;
import Game.Character;
import Game.Model;

public class Pacman extends Character {
    static {
        TimerThread timerThread = new TimerThread();
        timerThread.start();
    }

    public Pacman(int row, int column, int speed) {
        super(row, column, speed);
        animation.put(Inputs.UP, new String[]{"src/Images/PacmanUp1.png", "src/Images/PacmanUp2.png", "src/Images/PacmanUp3.png"});
        animation.put(Inputs.DOWN, new String[]{"src/Images/PacmanDown1.png", "src/Images/PacmanDown2.png", "src/Images/PacmanDown3.png"});
        animation.put(Inputs.RIGHT, new String[]{"src/Images/PacmanRight1.png", "src/Images/PacmanRight2.png", "src/Images/PacmanRight3.png"});
        animation.put(Inputs.LEFT, new String[]{"src/Images/PacmanLeft1.png", "src/Images/PacmanLeft2.png", "src/Images/PacmanLeft3.png"});
        animated = new Animation(animation.get(inputs), 0.25);
    }

    @Override
    public void update(Model model) {
        lastSecUpdate = TimerThread.getCurrentTimeMillis();
        int newRow = getRow();
        int newColumn = getColumn();

        switch (getInputs()) {
            case Inputs.UP -> newRow--;
            case Inputs.DOWN -> newRow++;
            case Inputs.LEFT -> newColumn--;
            case Inputs.RIGHT -> newColumn++;
        }
        if (newColumn == -1) {
            this.column = model.getGameBoard().length - 1;
            return;
        }
        if (newColumn == model.getGameBoard().length) {
            this.column = 0;
            return;
        }
        if (newRow == -1) {
            this.row = model.getGameBoard().length - 1;
            return;
        }
        if (newRow == model.getGameBoard().length) {
            this.row = 0;
            return;
        }
        if (model.getGameBoard()[newRow][newColumn].isMovable()) {
            setColumn(newColumn);
            setRow(newRow);
        }
    }

    private static class TimerThread extends Thread {
        private static long currentTimeMillis = System.currentTimeMillis();

        public static long getCurrentTimeMillis() {
            return currentTimeMillis;
        }

        @Override
        public void run() {
            while (true) {
                currentTimeMillis = System.currentTimeMillis();
                try {
                    Thread.sleep(10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }


}
