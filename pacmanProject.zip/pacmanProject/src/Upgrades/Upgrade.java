package Upgrades;

import Enums.UpgradeType;
import Game.Model;

public abstract class Upgrade {
    protected int duration;
    protected long lastTimeMillis;
    protected String image;

    public abstract void start(Model model);

    public abstract void reset(Model model);

    public int getDuration() {
        return duration;
    }

    public String getImage() {
        return image;
    }

    public long getLastTimeMillis() {
        return lastTimeMillis;
    }

    public void setLastTimeMillis(long lastTimeMillis) {
        this.lastTimeMillis = lastTimeMillis;
    }

    public abstract UpgradeType getUpgradeType();
}
