package Upgrades;

import Characters.Pacman;
import Enums.UpgradeType;
import Game.Model;

public class UpgradeManager extends Upgrade {
    private final UpgradeType upgradeType;

    public UpgradeManager(UpgradeType upgradeType) {
        this.upgradeType = upgradeType;
        initializeAttributes();
    }

    private void initializeAttributes() {
        switch (upgradeType) {
            case POINT_DOUBLE:
                duration = 5000;
                image = "src/Images/strawberryFruit.png";
                break;
            case POINT_TRIPLE:
                duration = 2500;
                image = "src/Images/grapeFruit.png";
                break;
            case SPEED:
                duration = 3000;
                image = "src/Images/cherry.png";
                break;
            case IMMORTALITY:
                duration = 3000;
                image = "src/Images/watermelonFruit.png";
                break;
            case ALL:
                duration = 5000;
                image = "src/Images/avacadoFruit.png";
                break;

        }
    }

    @Override
    public void start(Model model) {
        switch (upgradeType) {
            case SPEED:
            case ALL:
                Pacman pacman = model.getPacman();
                pacman.setSpeed(pacman.getSpeed() / 2);
                break;
        }
    }

    @Override
    public void reset(Model model) {
        switch (upgradeType) {
            case SPEED:
            case ALL:
                Pacman pacman = model.getPacman();
                pacman.setSpeed(pacman.getSpeed() * 2);
                break;
        }
    }

    @Override
    public UpgradeType getUpgradeType() {
        return upgradeType;
    }


}
