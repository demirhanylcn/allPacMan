package Menu;


public class Controller {
    private final View view;

    public Controller(View view) {
        this.view = view;
    }

    public void showMenu() {
        view.showMenu();
    }
}
