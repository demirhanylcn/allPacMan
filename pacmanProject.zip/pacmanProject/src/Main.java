

public class Main {
    public static void main(String[] args) {


        Score.Model sModel = new Score.Model();
        Score.View sView = new Score.View (sModel);
        Score.Controller sController = new Score.Controller(sModel, sView);

        Game.Model gModel = new Game.Model();
        Game.View gView = new Game.View(gModel,sModel);
        Game.Controller gController = new Game.Controller(gView, gModel, sController);
        gView.setController(gController);

        Menu.View mView = new Menu.View(gController, sController);
        Menu.Controller mController = new Menu.Controller(mView);

        mController.showMenu();


    }
}
