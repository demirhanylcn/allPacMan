package Score;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;

public class View extends JFrame {
    private final Model model;
    private final JList<String> list;
    private final Font font = new Font("Monospaced", Font.BOLD, 25);

    public View(Model model) {
        this.model = model;
        list = new JList<>();
        setupUI();
    }

    private void setupUI() {

        JScrollPane scrollPane = new JScrollPane(list);
        list.setLayoutOrientation(JList.VERTICAL);
        list.setBackground(Color.BLACK);
        list.setForeground(Color.ORANGE);
        list.setFont(font);
        list.setCellRenderer(new CustomListCellRenderer());

        add(scrollPane, BorderLayout.CENTER);

        ImageIcon icon = new ImageIcon("src/Images/blueGhostDown.png");
        setIconImage(icon.getImage());

        setTitle("Scores");
        setSize(600, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    public void updateScores() {
        DefaultListModel<String> modelList = new DefaultListModel<>();
        for (Score score : model.getScores()) {
            modelList.addElement(score.toString());
        }

        SwingUtilities.invokeLater(() -> list.setModel(modelList));
    }

    public void showScore() {
        setVisible(true);
    }

    private static class CustomListCellRenderer extends DefaultListCellRenderer {
        @Override
        public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
            Component component = super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);

            if (index < list.getModel().getSize() - 1) {
                Border originalBorder = ((JComponent) component).getBorder();
                Border lineBorder = BorderFactory.createMatteBorder(0, 0, 1, 0, Color.ORANGE);
                ((JComponent) component).setBorder(BorderFactory.createCompoundBorder(originalBorder, lineBorder));
            }

            return component;
        }
    }
}

