package Enums;

public enum UpgradeType {

    POINT_DOUBLE, POINT_TRIPLE, SPEED, IMMORTALITY, ALL

}
