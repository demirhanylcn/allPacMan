package Enums;

public enum CellType {
    EMPTY, POINT, UPGRADE, WALL
}
