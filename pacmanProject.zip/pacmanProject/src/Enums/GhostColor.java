package Enums;

public enum GhostColor {
    RED, PINK, ORANGE, BLUE
}
