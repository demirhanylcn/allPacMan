package Game;

import Cell.Cell;
import Characters.Pacman;
import Enums.CellType;
import Enums.Inputs;
import Enums.UpgradeType;
import Upgrades.Upgrade;
import Upgrades.UpgradeManager;

import javax.swing.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Controller {
    private final View view;
    private final Model model;
    private final List<Thread> gameThreads = new ArrayList<>();
    private final Score.Controller scoreController;

    public Controller(View view, Model model, Score.Controller scoreController) {
        this.scoreController = scoreController;
        this.view = view;
        this.model = model;
    }

    public void showGame() {

        model.initializeGame();
        model.setGameActive(true);
        view.showGame();

        Thread gameThread = new Thread(this::game);
        gameThreads.add(gameThread);
        gameThread.start();


        Thread updateTableThread = new Thread(this::updateTable);
        updateTableThread.start();
        gameThreads.add(updateTableThread);


        Thread spawnUpgrades = new Thread(this::spawnUpgrades);
        spawnUpgrades.start();
        gameThreads.add(spawnUpgrades);


        Thread calculatorUpgrades = new Thread(this::calculateUpgrades);
        calculatorUpgrades.start();
        gameThreads.add(calculatorUpgrades);

        for (Cell[] cells : model.gameBoard.getCells()) {
            for (Cell cell : cells) {
                view.setCellValue(cell, cell.getRow(), cell.getColumn());
            }
        }
    }

    private void game() {
        while (model.isGameActive()) {
            try {

                for (Character gameCharacter : model.getPlayerList()) {
                    if (System.currentTimeMillis() - gameCharacter.getLastSecUpdate() <= gameCharacter.getSpeed()) {
                        continue;
                    }

                    gameCharacter.update(model);
                    Cell currentCell = model.getGameBoard()[gameCharacter.getRow()][gameCharacter.getColumn()];

                    if (gameCharacter instanceof Pacman && currentCell.getCellType() == CellType.POINT) {
                        earnPoint(gameCharacter);
                    }

                    if (gameCharacter instanceof Pacman && currentCell.getCellType() == CellType.UPGRADE) {
                        addUpgrade(gameCharacter, currentCell);
                    }
                }
                handlePlayerHealth();
                handleGameEnd();


            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }

    private void updateCellAndModel(int row, int column) {
        Cell cell = new Cell(row, column, true, null, CellType.EMPTY);
        view.setCellValue(cell, row, column);
        model.gameBoard.cells[row][column] = cell;
    }

    private void earnPoint(Character pacman) {
        updateCellAndModel(pacman.getRow(), pacman.getColumn());
        addScore(100);
        view.updateScore();
    }

    private void addUpgrade(Character pacman, Cell cell) {
        updateCellAndModel(pacman.getRow(), pacman.getColumn());

        model.getUpgradeList().add(cell.getUpgrade());
        cell.getUpgrade().setLastTimeMillis(System.currentTimeMillis());
        cell.getUpgrade().start(model);

        view.updateBottomPanel();
    }

    private void handleGameEnd() {
        if (gameEnd()) {
            stopGame();
        }
    }

    private void handlePlayerHealth() {
        boolean isImmortalityActive = model.getUpgradeList().stream()
                .anyMatch(x ->
                        x.getUpgradeType() == UpgradeType.IMMORTALITY);

        boolean isUpgradeAllActive = model.getUpgradeList().stream()
                .anyMatch(x ->
                        x.getUpgradeType() == UpgradeType.ALL);

        if (model.getIfGhostTouchedPacman() && !isImmortalityActive && !isUpgradeAllActive) {
            model.setCurrentHealth(model.getCurrentHealth() - 1);
            model.resetCharacters();
            view.updateBottomPanel();
            view.updateBottomPanel();
        }

        if (model.getCurrentHealth() <= 0) {
            stopGame();
        }
    }


    private void updateTable() {
        while (model.isGameActive()) {
            try {
                view.repaintBoard();
                Thread.sleep(15);
            } catch (InterruptedException e) {
                System.out.println(e);
                Thread.currentThread().interrupt();
            }
        }
    }

    private void calculateUpgrades() {
        while (model.isGameActive()) {
            try {
                List<Upgrade> toRemove = new ArrayList<>();

                for (Upgrade upgrade : model.getUpgradeList()) {


                    if (System.currentTimeMillis() - upgrade.getLastTimeMillis() <= upgrade.getDuration()) continue;

                    upgrade.reset(model);
                    toRemove.add(upgrade);
                }

                boolean updateBottomPanel = !toRemove.isEmpty();
                model.getUpgradeList().removeAll(toRemove);

                if (updateBottomPanel) {
                    SwingUtilities.invokeLater(view::updateBottomPanel);
                }

                Thread.sleep(100);

            } catch (InterruptedException e) {
                System.out.println(e);
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }


    private void spawnUpgrades() {
        Random randomGenerator = new Random();

        while (model.isGameActive()) {
            try {

                Thread.sleep(5000);
                int randomNumber = randomGenerator.nextInt(100);
                if (randomNumber <= 25) {
                    int[] availableUpgrades = new int[]{1, 2, 3, 4, 5};
                    int selectedUpgradeIndex = randomGenerator.nextInt(availableUpgrades.length);
                    Upgrade selectedUpgrade = getUpgrade(availableUpgrades[selectedUpgradeIndex]);

                    List<Character> characters = model.getPlayerList().stream()
                            .filter(player -> !(player instanceof Pacman))
                            .toList();

                    Character selectedCharacter = characters.get(randomGenerator.nextInt(characters.size()));

                    Cell cell = new Cell(selectedCharacter.getRow(), selectedCharacter.getColumn(), true, selectedUpgrade, CellType.UPGRADE);

                    view.setCellValue(cell, selectedCharacter.getRow(), selectedCharacter.getColumn());
                    model.gameBoard.cells[selectedCharacter.getRow()][selectedCharacter.getColumn()] = cell;


                }
            } catch (InterruptedException e) {
                System.out.println(e);
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                System.out.println(e);
            }
        }
    }

    private static Upgrade getUpgrade(int availableUpgrades) {

        return switch (availableUpgrades) {
            case 1 -> new UpgradeManager(UpgradeType.SPEED);
            case 2 -> new UpgradeManager(UpgradeType.IMMORTALITY);
            case 3 -> new UpgradeManager(UpgradeType.POINT_DOUBLE);
            case 4 -> new UpgradeManager(UpgradeType.POINT_TRIPLE);
            default -> new UpgradeManager(UpgradeType.ALL);
        };
    }

    public void setPacmanDirection(Inputs inputs) {
        Pacman pacman = model.getPacman();
        pacman.setDirection(inputs);
    }

    public void stopGame() {
        String name = View.getUserName();
        scoreController.save(name, model.getCurrentScore());
        view.setVisible(false);
        gameThreads.forEach(Thread::interrupt);
        gameThreads.clear();
        model.initializeGame();
        view.updateBottomPanel();
    }

    public void addScore(int score) {
        int scoreMultiplier = 1;

        for (Upgrade upgrade : model.getUpgradeList()) {
            UpgradeType upgradeType = upgrade.getUpgradeType();
            switch (upgradeType) {
                case POINT_DOUBLE:
                    scoreMultiplier *= 2;
                    break;
                case POINT_TRIPLE:
                    scoreMultiplier *= 3;
                    break;
            }
        }

        model.setCurrentScore(model.getCurrentScore() + score * scoreMultiplier);
    }


    public boolean gameEnd() {
        for (int i = 0; i < model.getGameBoard().length; i++) {
            for (int j = 0; j < model.getGameBoard()[i].length; j++) {
                if (model.getGameBoard()[i][j].getCellType() == CellType.POINT) {
                    return false;
                }
            }
        }
        return true;
    }
}
