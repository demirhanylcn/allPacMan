package Game;

import Enums.Inputs;

import java.util.*;

public abstract class Character {
    static {
        TimerThread timerThread = new TimerThread();
        timerThread.start();
    }

    protected final Map<Inputs, String[]> animation = new HashMap<>();
    private final Random random;
    protected long lastSecUpdate;
    protected Animation animated;
    protected Inputs inputs;
    protected int row;
    protected int column;
    protected int speed;

    public Character(int row, int column, int speed) {
        inputs = Inputs.RIGHT;
        this.row = row;
        this.speed = speed;
        this.column = column;
        this.random = new Random();
    }

    public void update(Model model) {
        lastSecUpdate = TimerThread.getCurrentTimeMillis();
        int newRow = getRow();
        int newColumn = getColumn();

        switch (getInputs()) {
            case Inputs.UP -> newRow--;
            case Inputs.DOWN -> newRow++;
            case Inputs.LEFT -> newColumn--;
            case Inputs.RIGHT -> newColumn++;
        }
        if (newColumn == -1) {
            this.column = model.getGameBoard().length - 1;
            return;
        }
        if (newColumn == model.getGameBoard().length) {
            this.column = 0;
            return;
        }
        if (newRow == -1) {
            this.row = model.getGameBoard().length - 1;
            return;
        }
        if (newRow == model.getGameBoard().length) {
            this.row = 0;
            return;
        }
        if (model.getGameBoard()[newRow][newColumn].isMovable()) {
            this.row = newRow;
            this.column = newColumn;
            setDirection(getRandomDirectionOpposite(model));

        } else if (!(model.getGameBoard()[newRow][newColumn].isMovable())) {
            setDirection(getRandomDirectionOpposite(model));
        }
    }

    private Inputs getRandomDirectionOpposite(Model model) {
        List<Inputs> inputsList = new ArrayList<>(Arrays.stream(Inputs.values()).filter(x -> x.opposite() != getInputs()).toList());
        if (!(model.getGameBoard()[row][column - 1].isMovable())) {
            inputsList.remove(Inputs.LEFT);
        }
        if (!(model.getGameBoard()[row][column + 1].isMovable())) {
            inputsList.remove(Inputs.RIGHT);
        }
        if (!(model.getGameBoard()[row - 1][column].isMovable())) {
            inputsList.remove(Inputs.UP);
        }
        if (!(model.getGameBoard()[row + 1][column].isMovable())) {
            inputsList.remove(Inputs.DOWN);
        }
        if (inputsList.isEmpty()) {
            return inputs.opposite();
        }
        return inputsList.get(random.nextInt(inputsList.size()));
    }

    public Animation getAnimated() {
        return animated;
    }

    public Inputs getInputs() {
        return inputs;
    }

    public void setDirection(Inputs inputs) {
        this.inputs = inputs;
        animated.setFrame(animation.get(inputs));
    }

    public int getRow() {
        return row;
    }

    public void setRow(int row) {
        this.row = row;
    }

    public int getColumn() {
        return column;
    }

    public void setColumn(int column) {
        this.column = column;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public long getLastSecUpdate() {
        return lastSecUpdate;
    }

    private static class TimerThread extends Thread {
        private static long currentTimeMillis = System.currentTimeMillis();

        public static long getCurrentTimeMillis() {
            return currentTimeMillis;
        }

        @Override
        public void run() {
            while (true) {
                currentTimeMillis = System.currentTimeMillis();
                try {
                    Thread.sleep(10);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
