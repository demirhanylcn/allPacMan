package Game;

import Cell.Cell;

import javax.swing.table.AbstractTableModel;

public class BoardModel extends AbstractTableModel {
    private final TableM gameTableModel;

    public BoardModel(TableM gameTableModel) {
        this.gameTableModel = gameTableModel;
    }

    @Override
    public int getRowCount() {
        return gameTableModel.cells.length;
    }

    @Override
    public int getColumnCount() {
        return gameTableModel.cells[0].length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return gameTableModel.cells[rowIndex][columnIndex];
    }

    @Override
    public void setValueAt(Object value, int rowIndex, int columnIndex) {
        gameTableModel.cells[rowIndex][columnIndex] = (Cell) value;
        fireTableCellUpdated(rowIndex, columnIndex);
    }
}