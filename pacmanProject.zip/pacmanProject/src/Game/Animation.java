package Game;

public class Animation {
    public String[] frames;

    public double duration;

    public Animation(String[] frames, double duration) {
        this.frames = frames;
        this.duration = duration;
    }

    public String getFrame(double time) {
        int index = (int) ((time % (frames.length * duration)) / duration);
        return frames[index];
    }

    public void setFrame(String[] frames) {
        this.frames = frames;
    }

}